package com_.example.mkwan.bfftest;

public class Quiz {
    private String question;
    private String chooseOne;
    private String chooseTwo;
    private String chooseThird;

    public Quiz(String question,String chooseOne,String chooseTwo,String chooseThird){
        this.question=question;
        this.chooseOne=chooseOne;
        this.chooseTwo=chooseTwo;
        this.chooseThird=chooseThird;
    }

    public String getQuestion(){
        return question;
    }

    public String getChooseOne(){
        return chooseOne;
    }

    public String getChooseTwo(){
        return chooseTwo;
    }

    public String getChooseThird(){
        return chooseThird;
    }

    public void setQuestion(String question){
        this.question=question;
    }

    public void setChooseOne(String chooseOne){
        this.chooseOne=chooseOne;
    }

    public void setChooseTwo(String chooseTwo){
        this.chooseTwo=chooseTwo;
    }

    public void setChooseThird(String chooseThird){
        this.chooseThird=chooseThird;
    }
}

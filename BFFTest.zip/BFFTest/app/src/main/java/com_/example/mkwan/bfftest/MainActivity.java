package com_.example.mkwan.bfftest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button startButton;
    Button tryAgain;
    int rate;
    LinearLayout firstLinear;
    LinearLayout secondLinear;
    LinearLayout thirdLinear;
    EditText friendsName;
    String friendName;
    TextView question;
    TextView optionOne;
    TextView optionTwo;
    TextView optionThird;
    TextView yourName;
    TextView total_percent;
    Quiz questionOne;
    Quiz questionTwo;
    Quiz questionThree;
    Quiz questionFour;
    Quiz questionFive;
    Quiz questionSix;
    Quiz questionSeven;
    Quiz questionEight;
    Quiz questionNine;
    Quiz questionTen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        startButton = findViewById(R.id.start_button);
        firstLinear = findViewById(R.id.first_linear);
        secondLinear = findViewById(R.id.second_linear);
        thirdLinear = findViewById(R.id.third_linear);
        friendsName = findViewById(R.id.friends_name);
        yourName = findViewById(R.id.your_name);

        question = findViewById(R.id.first_question);
        optionOne = findViewById(R.id.first_choose);
        optionTwo = findViewById(R.id.second_choose);
        optionThird = findViewById(R.id.third_choose);
        tryAgain = findViewById(R.id.try_again);
        total_percent = findViewById(R.id.rate_text);
       /* if (yourName.equals("") || friendName.equals("")) {
            Toast.makeText(MainActivity.this, "Enter both names!", Toast.LENGTH_LONG).show();
        }
*/

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String friendsNameString = friendsName.getText().toString();
                String yourNameString = yourName.getText().toString();
                if (yourNameString.equals("") || friendsNameString.equals("")) {
                    Toast.makeText(MainActivity.this, "Both Name is Required", Toast.LENGTH_LONG).show();
                } else {
                    firstLinear.setVisibility(LinearLayout.GONE);
                    secondLinear.setVisibility(LinearLayout.VISIBLE);
                    thirdLinear.setVisibility(LinearLayout.GONE);
                    friendName = String.valueOf(friendsName.getText());
                }
                questionOne = new Quiz("How do you make up with " + friendName + " after an arguments?", "We don't ever argue!", "Whoever is at fault apologise", "We both apologise");
                questionTwo = new Quiz("How often do you talk with " + friendName + " ?", "Almost everyday", "At least a few times a week", "A few times every month or so");
                questionThree = new Quiz("Do you find " + friendName + " funny?", "Yes", "Sometimes", "No");
                questionFour = new Quiz("Can you tell what " + friendName + " is thinking just by looking at them?", "Always", "Sometimes", "Never");
                questionFive = new Quiz("Have you heard all of " + friendName + " 's stories?", "Yes,I know them by heart", "I heared most of them", "I'm not sure");
                questionSix = new Quiz("Would you end your friendShip with " + friendName + " right now if you could?", "No", "Maybe", "Yes");
                questionSeven = new Quiz("Have you ever taken a trip together?", "Yes,we have been on lots of trips together", "Yes,a few time", "No");
                questionEight = new Quiz("Do you ever tease each other?", "Yes,all the time", "Occasionally", "Never");
                questionNine = new Quiz("Do you shop together?", "Yes all the Time", "Sometimes", "Never");
                questionTen = new Quiz("Does " + friendName + " support you?", "Yes ", "Sometimes", "No");

                question.setText(questionOne.getQuestion());
                optionOne.setText(questionOne.getChooseOne());
                optionTwo.setText(questionOne.getChooseTwo());
                optionThird.setText(questionOne.getChooseThird());

                optionOne.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (optionOne.getText().equals("We don't ever argue!")) {
                            rate = rate + 10;
                            question.setText(questionTwo.getQuestion());
                            optionOne.setText(questionTwo.getChooseOne());
                            optionTwo.setText(questionTwo.getChooseTwo());
                            optionThird.setText(questionTwo.getChooseThird());
                        } else if (optionOne.getText().equals("Almost everyday")) {
                            rate = rate + 10;
                            question.setText(questionThree.getQuestion());
                            optionOne.setText(questionThree.getChooseOne());
                            optionTwo.setText(questionThree.getChooseTwo());
                            optionThird.setText(questionThree.getChooseThird());
                        } else if (optionOne.getText().equals("Yes")) {
                            rate = rate + 10;
                            question.setText(questionFour.getQuestion());
                            optionOne.setText(questionFour.getChooseOne());
                            optionTwo.setText(questionFour.getChooseTwo());
                            optionThird.setText(questionFour.getChooseThird());
                        } else if (optionOne.getText().equals("Always")) {
                            rate = rate + 10;
                            question.setText(questionFive.getQuestion());
                            optionOne.setText(questionFive.getChooseOne());
                            optionTwo.setText(questionFive.getChooseTwo());
                            optionThird.setText(questionFive.getChooseThird());
                        } else if (optionOne.getText().equals("Yes,I know them by heart")) {
                            rate = rate + 10;
                            question.setText(questionSix.getQuestion());
                            optionOne.setText(questionSix.getChooseOne());
                            optionTwo.setText(questionSix.getChooseTwo());
                            optionThird.setText(questionSix.getChooseThird());
                        } else if (optionOne.getText().equals("No")) {
                            rate = rate + 10;
                            question.setText(questionSeven.getQuestion());
                            optionOne.setText(questionSeven.getChooseOne());
                            optionTwo.setText(questionSeven.getChooseTwo());
                            optionThird.setText(questionSeven.getChooseThird());
                        } else if (optionOne.getText().equals("Yes,we have been on lots of trips together")) {
                            rate = rate + 10;
                            question.setText(questionEight.getQuestion());
                            optionOne.setText(questionEight.getChooseOne());
                            optionTwo.setText(questionEight.getChooseTwo());
                            optionThird.setText(questionEight.getChooseThird());
                        } else if (optionOne.getText().equals("Yes,all the time")) {
                            rate = rate + 10;
                            question.setText(questionNine.getQuestion());
                            optionOne.setText(questionNine.getChooseOne());
                            optionTwo.setText(questionNine.getChooseTwo());
                            optionThird.setText(questionNine.getChooseThird());
                        } else if (question.getText().equals("Do you shop together?")) {
                            rate = rate + 10;
                            question.setText(questionTen.getQuestion());
                            optionOne.setText(questionTen.getChooseOne());
                            optionTwo.setText(questionTen.getChooseTwo());
                            optionThird.setText(questionTen.getChooseThird());
                        } else if (question.getText().equals("Does " + friendName + " support you?")) {
                            rate = rate + 10;
                            firstLinear.setVisibility(LinearLayout.GONE);
                            secondLinear.setVisibility(LinearLayout.GONE);
                            thirdLinear.setVisibility(LinearLayout.VISIBLE);
                            total_percent.setText("%" + rate);

                        }


                    }
                });

                optionTwo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (optionOne.getText().equals("We don't ever argue!")) {
                            rate = rate + 8;
                            question.setText(questionTwo.getQuestion());
                            optionOne.setText(questionTwo.getChooseOne());
                            optionTwo.setText(questionTwo.getChooseTwo());
                            optionThird.setText(questionTwo.getChooseThird());
                        } else if (optionOne.getText().equals("Almost everyday")) {
                            rate = rate + 8;
                            question.setText(questionThree.getQuestion());
                            optionOne.setText(questionThree.getChooseOne());
                            optionTwo.setText(questionThree.getChooseTwo());
                            optionThird.setText(questionThree.getChooseThird());
                        } else if (optionOne.getText().equals("Yes")) {
                            rate = rate + 8;
                            question.setText(questionFour.getQuestion());
                            optionOne.setText(questionFour.getChooseOne());
                            optionTwo.setText(questionFour.getChooseTwo());
                            optionThird.setText(questionFour.getChooseThird());
                        } else if (optionOne.getText().equals("Always")) {
                            rate = rate + 8;
                            question.setText(questionFive.getQuestion());
                            optionOne.setText(questionFive.getChooseOne());
                            optionTwo.setText(questionFive.getChooseTwo());
                            optionThird.setText(questionFive.getChooseThird());
                        } else if (optionOne.getText().equals("Yes,I know them by heart")) {
                            rate = rate + 8;
                            question.setText(questionSix.getQuestion());
                            optionOne.setText(questionSix.getChooseOne());
                            optionTwo.setText(questionSix.getChooseTwo());
                            optionThird.setText(questionSix.getChooseThird());
                        } else if (optionOne.getText().equals("No")) {
                            rate = rate + 8;
                            question.setText(questionSeven.getQuestion());
                            optionOne.setText(questionSeven.getChooseOne());
                            optionTwo.setText(questionSeven.getChooseTwo());
                            optionThird.setText(questionSeven.getChooseThird());
                        } else if (optionOne.getText().equals("Yes,we have been on lots of trips together")) {
                            rate = rate + 8;
                            question.setText(questionEight.getQuestion());
                            optionOne.setText(questionEight.getChooseOne());
                            optionTwo.setText(questionEight.getChooseTwo());
                            optionThird.setText(questionEight.getChooseThird());
                        } else if (optionOne.getText().equals("Yes,all the time")) {
                            rate = rate + 8;
                            question.setText(questionNine.getQuestion());
                            optionOne.setText(questionNine.getChooseOne());
                            optionTwo.setText(questionNine.getChooseTwo());
                            optionThird.setText(questionNine.getChooseThird());
                        } else if (question.getText().equals("Do you shop together?")) {
                            rate = rate + 8;
                            question.setText(questionTen.getQuestion());
                            optionOne.setText(questionTen.getChooseOne());
                            optionTwo.setText(questionTen.getChooseTwo());
                            optionThird.setText(questionTen.getChooseThird());
                        } else if (question.getText().equals("Does " + friendName + " support you?")) {
                            rate = rate + 8;
                            firstLinear.setVisibility(LinearLayout.GONE);
                            secondLinear.setVisibility(LinearLayout.GONE);
                            thirdLinear.setVisibility(LinearLayout.VISIBLE);
                            total_percent.setText("%" + rate);

                        }


                    }
                });

                optionThird.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (optionOne.getText().equals("We don't ever argue!")) {
                            rate = rate + 5;
                            question.setText(questionTwo.getQuestion());
                            optionOne.setText(questionTwo.getChooseOne());
                            optionTwo.setText(questionTwo.getChooseTwo());
                            optionThird.setText(questionTwo.getChooseThird());
                        } else if (optionOne.getText().equals("Almost everyday")) {
                            rate = rate + 5;
                            question.setText(questionThree.getQuestion());
                            optionOne.setText(questionThree.getChooseOne());
                            optionTwo.setText(questionThree.getChooseTwo());
                            optionThird.setText(questionThree.getChooseThird());
                        } else if (optionOne.getText().equals("Yes")) {
                            rate = rate + 5;
                            question.setText(questionFour.getQuestion());
                            optionOne.setText(questionFour.getChooseOne());
                            optionTwo.setText(questionFour.getChooseTwo());
                            optionThird.setText(questionFour.getChooseThird());
                        } else if (optionOne.getText().equals("Always")) {
                            rate = rate + 5;
                            question.setText(questionFive.getQuestion());
                            optionOne.setText(questionFive.getChooseOne());
                            optionTwo.setText(questionFive.getChooseTwo());
                            optionThird.setText(questionFive.getChooseThird());
                        } else if (optionOne.getText().equals("Yes,I know them by heart")) {
                            rate = rate + 5;
                            question.setText(questionSix.getQuestion());
                            optionOne.setText(questionSix.getChooseOne());
                            optionTwo.setText(questionSix.getChooseTwo());
                            optionThird.setText(questionSix.getChooseThird());
                        } else if (optionOne.getText().equals("No")) {
                            rate = rate + 5;
                            question.setText(questionSeven.getQuestion());
                            optionOne.setText(questionSeven.getChooseOne());
                            optionTwo.setText(questionSeven.getChooseTwo());
                            optionThird.setText(questionSeven.getChooseThird());
                        } else if (optionOne.getText().equals("Yes,we have been on lots of trips together")) {
                            rate = rate + 5;
                            question.setText(questionEight.getQuestion());
                            optionOne.setText(questionEight.getChooseOne());
                            optionTwo.setText(questionEight.getChooseTwo());
                            optionThird.setText(questionEight.getChooseThird());
                        } else if (optionOne.getText().equals("Yes,all the time")) {
                            rate = rate + 5;
                            question.setText(questionNine.getQuestion());
                            optionOne.setText(questionNine.getChooseOne());
                            optionTwo.setText(questionNine.getChooseTwo());
                            optionThird.setText(questionNine.getChooseThird());
                        } else if (question.getText().equals("Do you shop together?")) {
                            rate = rate + 5;
                            question.setText(questionTen.getQuestion());
                            optionOne.setText(questionTen.getChooseOne());
                            optionTwo.setText(questionTen.getChooseTwo());
                            optionThird.setText(questionTen.getChooseThird());
                        } else if (question.getText().equals("Does " + friendName + " support you?")) {
                            rate = rate + 5;
                            firstLinear.setVisibility(LinearLayout.GONE);
                            secondLinear.setVisibility(LinearLayout.GONE);
                            thirdLinear.setVisibility(LinearLayout.VISIBLE);
                            total_percent.setText("%" + rate);

                        }


                    }
                });
                tryAgain.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        rate = 0;
                        firstLinear.setVisibility(LinearLayout.VISIBLE);
                        secondLinear.setVisibility(LinearLayout.GONE);
                        thirdLinear.setVisibility(LinearLayout.GONE);
                        total_percent.setText("%" + rate);
                    }
                });


            }
        });

    }
}
